
##  Operator-Mono

## Description
一Very good code font, made a backup here

## Font Installation

#### 1. Clone resource

    $ git clone https://github.com/ScumPetard/Operator-Mono.git




